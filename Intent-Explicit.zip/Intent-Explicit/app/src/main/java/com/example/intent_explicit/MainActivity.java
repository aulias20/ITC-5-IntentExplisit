package com.example.intent_explicit;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    EditText pass, user;
    ImageView button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        pass = findViewById(R.id.edtpass);
        user = findViewById(R.id.edtuser);
        button = findViewById(R.id.imgbtn);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = user.getText().toString();
                String password = pass.getText().toString();

                if(username.equals("namaku") && password.equals("ultahku")){
                    Intent intent = new Intent(MainActivity.this, Home.class);
                    intent.putExtra(Home.extra_user, username);
                    startActivity(intent);
                }
            }
        });
    }
}
