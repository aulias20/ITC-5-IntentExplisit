package com.example.intent_explicit;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class Home extends AppCompatActivity {
    final static String extra_user = "extra_user";
    TextView txtGetuser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        String username = getIntent().getStringExtra(extra_user);
        txtGetuser = findViewById(R.id.txtgetuser);
        txtGetuser.setText("User : "+username);
    }
}
